// add middlewares here related to projects
